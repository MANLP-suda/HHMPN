import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np
import lamp.Constants as Constants
from pdb import set_trace as stop 


def position_encoding_init(n_position, d_pos_vec):
    ''' Init the sinusoid position encoding table '''

    # keep dim 0 for padding token position encoding zero vector
    position_enc = np.array([
        [pos / np.power(10000, 2 * (j // 2) / d_pos_vec) for j in range(d_pos_vec)]
        if pos != 0 else np.zeros(d_pos_vec) for pos in range(n_position)])

    position_enc[1:, 0::2] = np.sin(position_enc[1:, 0::2]) # dim 2i
    position_enc[1:, 1::2] = np.cos(position_enc[1:, 1::2]) # dim 2i+1
    return torch.from_numpy(position_enc).type(torch.FloatTensor)

def onehot_init(n_src_vocab, d_word_vec):    
    return torch.from_numpy(position_enc).type(torch.FloatTensor)


def get_attn_src_mask(seq_q,seq_k,unsqueeze=True):
    assert seq_k.dim()==3 and seq_k.dim()==3
    mb_size,len_q,dim=seq_q.size()
    mb_size,len_k,dim=seq_k.size()
    pad_dim=torch.zeros(dim)
    pad_attn_mask=torch.tensor([[line.equal(pad_dim) for line in seq]for seq in seq_k.data]).unsqueeze(1)
    if unsqueeze:
        pad_attn_mask=pad_attn_mask.expand(mb_size,len_q,len_k)
    return pad_attn_mask
def get_attn_tgt_src_mask(seq_q,seq_k,unsqueeze=True):
    assert seq_q.dim()==2 and seq_k.dim()==3
    mb_size,len_q = seq_q.size()
    mb_size,len_k,dim = seq_k.size()
    pad_dim=torch.zeros(dim)
    pad_attn_mask=torch.tensor([[line.equal(pad_dim) for line in seq]for seq in seq_k.data]).unsqueeze(1)
    if unsqueeze:
        pad_attn_mask=pad_attn_mask.expand(mb_size,len_q,len_k)
    return pad_attn_mask
def get_attn_padding_mask(seq_q, seq_k, unsqueeze=True):
    ''' Indicate the padding-related part to mask '''
    assert seq_q.dim() == 2 and seq_k.dim() == 2
    mb_size, len_q = seq_q.size()
    mb_size, len_k = seq_k.size()
    pad_attn_mask = seq_k.data.eq(Constants.PAD).unsqueeze(1)   # bx1xsk
    if unsqueeze:
        pad_attn_mask = pad_attn_mask.expand(mb_size, len_q, len_k) # bxsqxsk
    return pad_attn_mask

def get_attn_subsequent_mask(seq):
    ''' Get an attention mask to avoid using the subsequent info.'''
    assert seq.dim() == 2
    attn_shape = (seq.size(0), seq.size(1), seq.size(1))
    subsequent_mask = np.triu(np.ones(attn_shape), k=1).astype('uint8')
    subsequent_mask = torch.from_numpy(subsequent_mask)
    if seq.is_cuda:
        subsequent_mask = subsequent_mask.cuda()
    return subsequent_mask

def swap_0_1(tensor, on_zero, on_non_zero):
    res = tensor.clone()
    res[tensor==0] = on_zero
    res[tensor!=0] = on_non_zero
    return res